#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
QEMU_BIN="${NOVA_QEMU:-qemu-system-x86_64}"
command -v "$QEMU_BIN" >/dev/null || { echo "Missing QEMU: $QEMU_BIN" >&2; exit 1; }
OVMF_CODE="${OVMF_CODE:-}"
if [[ -z "$OVMF_CODE" ]]; then
  for candidate in /usr/share/OVMF/OVMF_CODE_4M.fd /usr/share/OVMF/OVMF_CODE.fd /usr/share/edk2/ovmf/OVMF_CODE.fd /usr/share/edk2/x64/OVMF_CODE.4m.fd; do
    if [[ -f "$candidate" ]]; then OVMF_CODE="$candidate"; break; fi
  done
fi
[[ -f "$OVMF_CODE" ]] || { echo 'Set OVMF_CODE to an OVMF firmware image' >&2; exit 1; }
OVMF_VARS="${OVMF_VARS:-${OVMF_CODE/CODE/VARS}}"
[[ -f "$OVMF_VARS" ]] || { echo 'Set OVMF_VARS to the matching variables template' >&2; exit 1; }
cp "$OVMF_VARS" "$ROOT/OVMF_VARS.runtime.fd"
DATA_ARGS=()
[[ -z "${NOVA_QEMU_DATADIR:-}" ]] || DATA_ARGS=(-L "$NOVA_QEMU_DATADIR")
DISPLAY_ARGS=()
[[ -z "${NOVA_DISPLAY:-}" ]] || DISPLAY_ARGS=(-display "$NOVA_DISPLAY")
exec "$QEMU_BIN" "${DATA_ARGS[@]}" -machine q35 -m "${NOVA_RAM:-256M}" -cpu qemu64 -smp "${NOVA_SMP:-1}" \
  -drive "if=pflash,format=raw,readonly=on,file=$OVMF_CODE" \
  -drive "if=pflash,format=raw,file=$ROOT/OVMF_VARS.runtime.fd" \
  -drive "if=ide,index=0,format=raw,file=$ROOT/nova-efi.img" \
  -drive "if=none,id=nova-system,format=raw,file=$ROOT/nova-system.img" \
  -device virtio-blk-pci,drive=nova-system,disable-modern=on \
  -device VGA "${DISPLAY_ARGS[@]}" -serial stdio -no-reboot "$@"
