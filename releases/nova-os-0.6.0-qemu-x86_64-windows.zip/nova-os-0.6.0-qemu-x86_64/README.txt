Nova OS x86_64 / UEFI QEMU development image

This archive contains two raw FAT32 disks:
  nova-efi.img     UEFI NovaBoot and Nova Kernel
  nova-system.img  Nova system files and userspace programs

Requirements: qemu-system-x86_64 and OVMF_CODE_4M.fd / OVMF_VARS_4M.fd.
Run ./run-qemu.sh from this directory. The script detects common OVMF paths;
set OVMF_CODE and OVMF_VARS if yours differ. Set NOVA_SMP=4 or NOVA_RAM=1G
to change the VM. Set NOVA_DISPLAY=none for headless serial output.

On Windows, double-click run-qemu-windows.bat. Install QEMU for Windows first.
The BAT file checks common QEMU paths. If its bundled UEFI firmware is absent,
copy OVMF_CODE_4M.fd and OVMF_VARS_4M.fd beside the BAT, or set OVMF_CODE
and OVMF_VARS to the matching files. Keep both IMG files in this directory.

The system image is a fresh development volume. Nova 0.6.0 starts additional
APs, but its user scheduler still runs on the bootstrap CPU. This package
does not claim full SMP or support for physical PCs.
